// background.js

const discoveredVideos = {}; 
// Key: normalizedUrl, value: { realUrl, partialBase64, ... }

// Listen for response headers to detect "video/mp4"
chrome.webRequest.onHeadersReceived.addListener(
  async function(details) {
    let isMp4 = false;
    for (const header of details.responseHeaders) {
      if (
        header.name.toLowerCase() === "content-type" &&
        header.value.includes("video/mp4")
      ) {
        isMp4 = true;
        break;
      }
    }
    if (!isMp4) return;

    const actualUrl = details.url;
    const normUrl = normalizeUrl(actualUrl);

    debugLogAllTabs(`[BG] onHeadersReceived => MP4: ${actualUrl} => norm: ${normUrl}`);

    // If not processed yet, partial fetch for thumbnail
    if (!discoveredVideos[normUrl]) {
      discoveredVideos[normUrl] = { realUrl: actualUrl, partialBase64: null };
      try {
        debugLogAllTabs(`[BG] Partial fetch start: ${actualUrl}`);
        const base64Partial = await fetchPartialMp4(actualUrl);
        discoveredVideos[normUrl].partialBase64 = base64Partial;
        debugLogAllTabs(`[BG] Partial fetch success: ${actualUrl}`);

        // Notify content script
        chrome.tabs.query({}, (tabs) => {
          for (const tab of tabs) {
            chrome.tabs.sendMessage(tab.id, {
              type: "TIKTOK_VIDEO_THUMBNAIL",
              normalizedUrl: normUrl,
              realUrl: actualUrl,
              partialData: base64Partial
            });
          }
        });
      } catch (err) {
        debugLogAllTabs(`[BG] Partial fetch FAILED: ${actualUrl} => ${err}`);
        discoveredVideos[normUrl] = null;
      }
    }
  },
  { urls: ["*://*.tiktok.com/*"] },
  ["responseHeaders"]
);

// Listen for download requests from content script
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "DOWNLOAD_SINGLE") {
    // Download one file
    const { realUrl } = msg;
    debugLogAllTabs(`[BG] DOWNLOAD_SINGLE => ${realUrl}`);
    doChromeDownload(realUrl, "tiktok-video.mp4")
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;

  } else if (msg.type === "DOWNLOAD_MULTIPLE") {
    // Download multiple files
    const { realUrls } = msg;
    debugLogAllTabs(`[BG] DOWNLOAD_MULTIPLE => ${realUrls.length} items`);

    // We'll do each download in sequence or parallel
    // Let's do them in parallel for simplicity
    Promise.all(realUrls.map(url => 
      doChromeDownload(url, "tiktok-video.mp4").catch(e => e) // keep going
    ))
    .then(() => {
      sendResponse({ success: true });
    })
    .catch((err) => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }
});

/**
 * Partial fetch for ~2MB
 */
async function fetchPartialMp4(url) {
  const rangeHeader = "bytes=0-2097151"; // ~2MB
  const resp = await fetch(url, {
    headers: {
      "Range": rangeHeader
      // Add 'User-Agent'/'Referer' if needed to avoid 403
    }
  });
  if (!resp.ok && resp.status !== 206 && resp.status !== 200) {
    throw new Error(`Partial fetch failed (status=${resp.status})`);
  }
  const blob = await resp.blob();
  return blobToDataURL(blob);
}

/**
 * Actually downloads the file from ephemeral `realUrl` using chrome.downloads.download
 */
function doChromeDownload(realUrl, filename) {
  return new Promise((resolve, reject) => {
    // Attempt a direct download
    chrome.downloads.download({
      url: realUrl,
      filename: filename,
      saveAs: false
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(downloadId);
      }
    });
  });
}

/**
 * Convert Blob -> base64 data URL
 */
function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Normalize the URL so ephemeral query params (e.g. __rand) don't create duplicates
 */
function normalizeUrl(fullUrl) {
  const u = new URL(fullUrl);
  if (u.searchParams.has("__rand")) {
    u.searchParams.delete("__rand");
  }
  return u.toString();
}

/**
 * Broadcast debug logs to all tabs so content-script can show them
 */
function debugLogAllTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, { type: "DEBUG_LOG", message });
    }
  });
}
