// content-script.js

console.log("[TikTokInterceptor] Content script loaded.");

const processedVideos = {}; 
// Key: normalizedUrl -> { realUrl, frameUrl, selected: bool }

// ==== DEBUG PANEL (COLLAPSIBLE) ====
function createDebugPanel() {
  const panel = document.createElement('div');
  panel.id = "debugOverlay";
  panel.className = "debug-panel";

  const header = document.createElement('div');
  header.className = 'debug-header';
  header.textContent = "TikTok Debug Logs";
  panel.appendChild(header);

  const collapseBtn = document.createElement('button');
  collapseBtn.className = 'debug-collapse-btn';
  collapseBtn.textContent = '-';
  header.appendChild(collapseBtn);

  const logContainer = document.createElement('div');
  logContainer.className = 'debug-log-container';
  panel.appendChild(logContainer);

  document.body.appendChild(panel);

  // Collapse/expand logic
  let collapsed = false;
  collapseBtn.addEventListener('click', () => {
    collapsed = !collapsed;
    if (collapsed) {
      logContainer.style.display = 'none';
      collapseBtn.textContent = '+';
    } else {
      logContainer.style.display = 'block';
      collapseBtn.textContent = '-';
    }
  });

  return logContainer;
}

// We create the panel once
const debugLogContainer = createDebugPanel();

/** Append a line to debug panel */
function debugLog(msg) {
  const line = document.createElement('div');
  line.className = 'debug-log-line';
  line.textContent = msg;
  debugLogContainer.appendChild(line);
  debugLogContainer.scrollTop = debugLogContainer.scrollHeight;
}

// ==== GALLERY PANEL (TOP-RIGHT, 3x3 GRID) ====
function createGalleryPanel() {
  const panel = document.createElement('div');
  panel.id = "tiktokInterceptorPanel";
  panel.className = "tiktok-panel";

  // Controls at top: select all, deselect all, download selected
  const controlsDiv = document.createElement('div');
  controlsDiv.className = 'gallery-controls';

  const selectAllBtn = document.createElement('button');
  selectAllBtn.textContent = "Select All";
  selectAllBtn.className = 'gallery-btn';
  selectAllBtn.onclick = selectAllVideos;
  controlsDiv.appendChild(selectAllBtn);

  const deselectAllBtn = document.createElement('button');
  deselectAllBtn.textContent = "Deselect All";
  deselectAllBtn.className = 'gallery-btn';
  deselectAllBtn.onclick = deselectAllVideos;
  controlsDiv.appendChild(deselectAllBtn);

  const downloadSelectedBtn = document.createElement('button');
  downloadSelectedBtn.textContent = "Download Selected";
  downloadSelectedBtn.className = 'gallery-btn';
  downloadSelectedBtn.onclick = downloadSelectedVideos;
  controlsDiv.appendChild(downloadSelectedBtn);

  panel.appendChild(controlsDiv);

  // The grid container
  const gridContainer = document.createElement('div');
  gridContainer.className = 'gallery-grid';
  panel.appendChild(gridContainer);

  document.body.appendChild(panel);
  return gridContainer;
}

// We'll store references
let galleryGrid = null;

// If not exist, create
function getOrCreateGalleryPanel() {
  if (!galleryGrid) {
    galleryGrid = createGalleryPanel();
  }
  return galleryGrid;
}

// Listen for messages from background (debug or thumbnail)
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg.type === "DEBUG_LOG") {
    debugLog(msg.message);

  } else if (msg.type === "TIKTOK_VIDEO_THUMBNAIL") {
    const { normalizedUrl, realUrl, partialData } = msg;
    if (processedVideos[normalizedUrl]) {
      // Already processed
      debugLog(`[CS] Already processed: ${normalizedUrl}`);
      return;
    }
    processedVideos[normalizedUrl] = {
      realUrl,
      frameUrl: null,
      selected: false
    };
    debugLog(`[CS] decodeFirstFrame => ${realUrl}`);
    decodeFirstFrame(partialData)
      .then((pngUrl) => {
        debugLog(`[CS] decodeFirstFrame success: ${realUrl}`);
        processedVideos[normalizedUrl].frameUrl = pngUrl;
        addGalleryItem(normalizedUrl);
      })
      .catch((err) => {
        debugLog(`[CS] decodeFirstFrame error: ${err}`);
      });
  }
});

// Convert partial data -> first frame
function decodeFirstFrame(base64Mp4) {
  return new Promise((resolve, reject) => {
    const blob = dataURLToBlob(base64Mp4);
    const objUrl = URL.createObjectURL(blob);

    const vid = document.createElement('video');
    vid.style.display = 'none';
    vid.src = objUrl;
    vid.muted = true;
    document.body.appendChild(vid);

    vid.onloadeddata = () => {
      vid.currentTime = 0;
      vid.addEventListener('seeked', () => {
        const canvas = document.createElement('canvas');
        canvas.width = vid.videoWidth;
        canvas.height = vid.videoHeight;
        canvas.getContext('2d').drawImage(vid, 0, 0);
        const pngUrl = canvas.toDataURL('image/png');
        document.body.removeChild(vid);
        URL.revokeObjectURL(objUrl);
        resolve(pngUrl);
      }, { once: true });
    };
    vid.onerror = (e) => reject("Video decode error: " + e);
  });
}

// Add a new item to the 3x3 gallery
function addGalleryItem(normUrl) {
  const grid = getOrCreateGalleryPanel();
  const videoData = processedVideos[normUrl];

  // Create item element
  const itemDiv = document.createElement('div');
  itemDiv.className = 'gallery-item';

  // The checkbox
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.className = 'video-checkbox';
  checkbox.checked = videoData.selected;
  checkbox.onchange = () => {
    videoData.selected = checkbox.checked;
  };
  itemDiv.appendChild(checkbox);

  // Thumbnail
  const img = document.createElement('img');
  img.src = videoData.frameUrl;
  img.className = 'video-thumb';
  itemDiv.appendChild(img);

  // Download button
  const dlBtn = document.createElement('button');
  dlBtn.textContent = "Download";
  dlBtn.className = 'gallery-dl-btn';
  dlBtn.onclick = () => {
    debugLog(`[CS] Download button => ${videoData.realUrl}`);
    // Request background to do single download
    chrome.runtime.sendMessage(
      { type: "DOWNLOAD_SINGLE", realUrl: videoData.realUrl },
      (response) => {
        if (!response || !response.success) {
          debugLog(`[CS] Single download failed: ${response?.error}`);
        } else {
          debugLog(`[CS] Single download triggered for: ${videoData.realUrl}`);
        }
      }
    );
  };
  itemDiv.appendChild(dlBtn);

  grid.appendChild(itemDiv);
}

// "Select All" => set all selected = true
function selectAllVideos() {
  for (const k in processedVideos) {
    processedVideos[k].selected = true;
  }
  // Update checkboxes in DOM
  document.querySelectorAll('.video-checkbox').forEach(chk => {
    chk.checked = true;
  });
}

// "Deselect All"
function deselectAllVideos() {
  for (const k in processedVideos) {
    processedVideos[k].selected = false;
  }
  document.querySelectorAll('.video-checkbox').forEach(chk => {
    chk.checked = false;
  });
}

// "Download Selected"
function downloadSelectedVideos() {
  const realUrls = [];
  for (const k in processedVideos) {
    if (processedVideos[k].selected) {
      realUrls.push(processedVideos[k].realUrl);
    }
  }
  if (realUrls.length === 0) {
    debugLog("[CS] No videos selected.");
    return;
  }
  debugLog(`[CS] Downloading ${realUrls.length} selected videos...`);

  // Ask background to do multiple downloads
  chrome.runtime.sendMessage(
    { type: "DOWNLOAD_MULTIPLE", realUrls },
    (response) => {
      if (!response || !response.success) {
        debugLog(`[CS] Multi download error: ${response?.error}`);
      } else {
        debugLog("[CS] Multi download triggered!");
      }
    }
  );
}

// Convert dataURL -> Blob
function dataURLToBlob(dataURL) {
  const [header, base64] = dataURL.split(",");
  const mime = header.match(/:(.*?);/)[1];
  const binary = atob(base64);
  const len = binary.length;
  const u8arr = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    u8arr[i] = binary.charCodeAt(i);
  }
  return new Blob([u8arr], { type: mime });
}
// (In content-script.js)
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg.type === "RESCAN") {
    // e.g. clear or re-check, etc.
    respond({ done: true });
  }
});
