// popup.js

document.getElementById('rescanBtn').addEventListener('click', () => {
  const statusEl = document.getElementById('status');
  statusEl.textContent = "Rescanning videos...";

  // Send a "RESCAN" message to the content script
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    if (!currentTab) {
      statusEl.textContent = "No active tab found.";
      return;
    }
    chrome.tabs.sendMessage(currentTab.id, { type: "RESCAN" }, (resp) => {
      statusEl.textContent = "Rescan triggered (if implemented).";
    });
  });
});
